import { createApp } from 'vue';
import './style.css';
import App from './App.vue';
import 'bootstrap/dist/css/bootstrap.min.css'; // Añade esta línea

createApp(App).mount('#app');

