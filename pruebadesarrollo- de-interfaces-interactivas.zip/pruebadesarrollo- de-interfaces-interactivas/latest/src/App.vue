<script setup>
import { ref, onMounted, computed } from 'vue';
import axios from 'axios';
import PokemonCard from './components/PokemonCard.vue';

const pokemons = ref([]);
const discoveredCount = computed(() => pokemons.value.filter(p => p.discovered).length);

const fetchPokemons = async () => {
  try {
    const response = await axios.get('https://pokeapi.co/api/v2/pokemon?limit=20');
    pokemons.value = response.data.results.map((pokemon, index) => ({
      ...pokemon,
      id: index + 1,
      discovered: false,
    }));
  } catch (error) {
    console.error('Error fetching Pokémon:', error);
  }
};

const markAsDiscovered = (pokemonId) => {
  const pokemon = pokemons.value.find(p => p.id === pokemonId);
  if (pokemon) pokemon.discovered = true;
};

onMounted(fetchPokemons);
</script>

<template>
  <div class="container">
    <h1 class="text-center my-4">¿Quién es este Pokémon?</h1>
    <p class="text-center">Pokémon descubiertos: {{ discoveredCount }}</p>
    
    <div class="row">
      <div
        v-for="pokemon in pokemons"
        :key="pokemon.id"
        class="col-6 col-md-3 mb-4 d-flex justify-content-center"
      >
        <PokemonCard
          :pokemon="pokemon"
          @discover="markAsDiscovered(pokemon.id)"
        />
      </div>
    </div>
  </div>
</template>

<style>
.container {
  max-width: 1200px;
  margin: auto;
}
</style>
