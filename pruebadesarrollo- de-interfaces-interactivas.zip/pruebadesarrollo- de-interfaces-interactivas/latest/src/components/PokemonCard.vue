<script setup>
import { ref, defineEmits } from 'vue';

const props = defineProps({
  pokemon: Object,
});

const emit = defineEmits();
const enteredName = ref('');
const isDiscovered = ref(false);

const checkName = () => {
  if (enteredName.value.toLowerCase() === props.pokemon.name.toLowerCase()) {
    isDiscovered.value = true;
    props.pokemon.discovered = true;
    emit('discover', props.pokemon.id);
  } else {
    alert('Nombre incorrecto, intenta nuevamente.');
  }
};
</script>

<template>
  <div class="card p-2 text-center" :class="{ 'bg-success text-white': isDiscovered }">
    <img
      :src="`https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/${props.pokemon.id}.png`"
      alt="pokemon"
      class="img-fluid"
      :style="{ filter: isDiscovered ? 'none' : 'brightness(0) saturate(100%)' }"
    />
    <div v-if="!isDiscovered">
      <p>¿Adivina el nombre?</p>
      <input
        v-model="enteredName"
        type="text"
        class="form-control mb-2"
        placeholder="Nombre del Pokémon"
      />
      <button @click="checkName" class="btn btn-primary">Descubrir</button>
    </div>
    <div v-else>
      <h5 class="mt-2">{{ props.pokemon.name }}</h5>
    </div>
  </div>
</template>

<style>
.card {
  width: 100%;
  max-width: 150px;
}
</style>

